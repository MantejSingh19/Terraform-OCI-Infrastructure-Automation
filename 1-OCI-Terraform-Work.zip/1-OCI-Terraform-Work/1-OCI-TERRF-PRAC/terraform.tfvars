region = ""

compartment_id = ""

availability_domain = ""

vcns = {

  VCN-1 = {

    cidr_block = "10.0.0.0/16"

    dns_label = "vcnone"
  }

  VCN-2 = {

    cidr_block = "172.16.0.0/16"

    dns_label = "vcntwo"
  }
}
subnets = {

  frontend-subnet = {

    vcn_name = "VCN-1"

    cidr_block = "10.0.0.0/16"

    dns_label = "frontend"

    prohibit_public_ip_on_vnic = false

    security_list_ids = []

    route_table_id = ""
  }

  backend-subnet = {

    vcn_name = "VCN-2"

    cidr_block = "172.16.1.0/24"

    dns_label = "backend"

    prohibit_public_ip_on_vnic = true

    security_list_ids = []

    route_table_id = ""
  }
}
security_lists = {

  frontend-sl = {

    vcn_name = "VCN-1"

    ingress_rules = [

      {
        protocol    = "6"
        source      = ""
        source_type = "CIDR_BLOCK"
        description = "Allow SSH"
        stateless   = false

        tcp_options = {
          min = 22
          max = 22
        }
      },

      {
        protocol    = "6"
        source      = ""
        source_type = "CIDR_BLOCK"
        description = "Allow HTTP"
        stateless   = false

        tcp_options = {
          min = 80
          max = 80
        }
      }
    ]

    egress_rules = [

      {
        protocol         = "all"
        destination      = "0.0.0.0/0"
        destination_type = "CIDR_BLOCK"
        description      = "Allow all outbound"
        stateless        = false
      }
    ]
  }
}
route_tables = {

  frontend-rt = {

    vcn_name = "VCN-1"

    route_rules = [

      {
        destination       = "0.0.0.0/0"

        destination_type  = "CIDR_BLOCK"

        network_entity_id = ""

        description       = "Internet Access"
      }
    ]
  }

  backend-rt = {

    vcn_name = "VCN-2"

    route_rules = [

      {
        destination       = "10.0.0.0/16"

        destination_type  = "CIDR_BLOCK"

        network_entity_id = ""

        description       = "NAT-GW Access"
      }
    ]
  }
}
instances = {

  frontend-vm = {

    subnet_name = "frontend-subnet"

    availability_domain = ""

    shape = ""

    ocpus = 1

    memory_in_gbs = 6

    assign_public_ip = true

    ssh_public_key_path = ""

    image_ocid = ""

    boot_volume_size_in_gbs = 50
  }
}
drgs = {

  core-drg = {

    display_name = "core-drg"
  }
}

drg_attachments = {

  attach-vcn1 = {

    drg_name = "core-drg"

    vcn_name = "VCN-1"
  }

  attach-vcn2 = {

    drg_name = "core-drg"

    vcn_name = "VCN-2"
  }

  attach-vcn3 = {

    drg_name = "core-drg"

    vcn_name = "VCN-3"
  }
}
lpgs = {

  vcn1-lpg = {

    vcn_name = "VCN-1"
  }

  vcn2-lpg = {

    vcn_name = "VCN-2"
  }
}
