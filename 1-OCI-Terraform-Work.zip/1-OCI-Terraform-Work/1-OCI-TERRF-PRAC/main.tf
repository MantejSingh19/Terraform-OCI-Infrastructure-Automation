module "vcn" {

  source = "./modules/VCN"

  compartment_id = var.compartment_id

  vcns = var.vcns
}

module "subnet" {

  source = "./modules/Subnet"

  compartment_id = var.compartment_id

  availability_domain = var.availability_domain

  vcn_ids = module.vcn.vcn_ids

  subnets = var.subnets

  depends_on = [module.vcn]
}

module "security_list" {

  source = "./modules/SL&SL-Rules"

  compartment_id = var.compartment_id

  vcn_ids = module.vcn.vcn_ids

  security_lists = var.security_lists

  depends_on = [module.vcn]
}

module "route_table" {

  source = "./modules/route-table"

  compartment_id = var.compartment_id

  vcn_ids = module.vcn.vcn_ids

  route_tables = var.route_tables

  depends_on = [module.vcn]
}

module "compute" {

  source = "./modules/Compute"

  compartment_id = var.compartment_id

  subnet_ids = module.subnet.subnet_ids

  instances = var.instances

  depends_on = [module.subnet]
}

module "drg" {

  source = "./modules/DRG"

  compartment_id = var.compartment_id

  drgs = var.drgs
}

module "drg_attachment" {

  source = "./modules/DRG-Attachment"

  drg_ids = module.drg.drg_ids

  vcn_ids = module.vcn.vcn_ids

  drg_attachments = var.drg_attachments

  depends_on = [
    module.drg,
    module.vcn
  ]
}
module "lpg" {

  source = "./modules/LPG"

  compartment_id = var.compartment_id

  vcn_ids = module.vcn.vcn_ids

  lpgs = var.lpgs

  depends_on = [module.vcn]
}
