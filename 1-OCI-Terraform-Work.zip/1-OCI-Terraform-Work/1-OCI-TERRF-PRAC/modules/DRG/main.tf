resource "oci_core_drg" "this" {

  for_each = var.drgs

  compartment_id = var.compartment_id

  display_name = each.value.display_name
}