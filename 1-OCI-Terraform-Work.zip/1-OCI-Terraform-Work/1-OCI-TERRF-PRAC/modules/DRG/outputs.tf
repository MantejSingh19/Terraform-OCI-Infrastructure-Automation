output "drg_ids" {

  description = "Map of DRG IDs"

  value = {

    for drg_name, drg_resource in oci_core_drg.this :

    drg_name => drg_resource.id
  }
}