variable "compartment_id" {

  description = "OCI Compartment OCID"

  type = string
}

variable "drgs" {

  description = "Map of DRG configurations"

  type = map(object({

    display_name = string
  }))
}