resource "oci_core_subnet" "this" {

  for_each = var.subnets

  compartment_id = var.compartment_id

  vcn_id = var.vcn_ids[each.value.vcn_name]

  cidr_block = each.value.cidr_block

  display_name = each.key

  dns_label = each.value.dns_label

  availability_domain = var.availability_domain

  prohibit_public_ip_on_vnic = each.value.prohibit_public_ip_on_vnic

  security_list_ids = length(each.value.security_list_ids) > 0 ? each.value.security_list_ids : null

  route_table_id = each.value.route_table_id
}