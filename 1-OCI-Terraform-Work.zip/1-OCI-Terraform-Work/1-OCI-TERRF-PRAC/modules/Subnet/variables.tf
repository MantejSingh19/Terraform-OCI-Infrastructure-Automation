variable "compartment_id" {

  description = "OCI Compartment OCID"

  type = string
}

variable "availability_domain" {

  description = "Availability Domain"

  type = string
}

variable "vcn_ids" {

  description = "Map of VCN IDs"

  type = map(string)
}

variable "subnets" {

  description = "Map of subnet configurations"

  type = map(object({

    vcn_name = string

    cidr_block = string

    dns_label = string

    prohibit_public_ip_on_vnic = bool

    security_list_ids = optional(list(string), [])

    route_table_id = optional(string)

  }))
}