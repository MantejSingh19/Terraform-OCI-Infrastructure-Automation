output "subnet_ids" {

  description = "Map of Subnet IDs"

  value = {

    for subnet_name, subnet_resource in oci_core_subnet.this :

    subnet_name => subnet_resource.id
  }
}