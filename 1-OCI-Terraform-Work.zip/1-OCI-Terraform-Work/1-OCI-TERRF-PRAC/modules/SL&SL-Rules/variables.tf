variable "compartment_id" {

  description = "OCI Compartment OCID"

  type = string
}

variable "vcn_ids" {

  description = "Map of VCN IDs"

  type = map(string)
}

variable "security_lists" {

  description = "Map of Security List configurations"

  type = map(object({

    vcn_name = string

    ingress_rules = list(object({

      protocol = string

      source = string

      source_type = string

      description = string

      stateless = bool

      tcp_options = optional(object({

        min = number

        max = number
      }))

      udp_options = optional(object({

        min = number

        max = number
      }))
    }))

    egress_rules = list(object({

      protocol = string

      destination = string

      destination_type = string

      description = string

      stateless = bool

      tcp_options = optional(object({

        min = number

        max = number
      }))

      udp_options = optional(object({

        min = number

        max = number
      }))
    }))
  }))
}