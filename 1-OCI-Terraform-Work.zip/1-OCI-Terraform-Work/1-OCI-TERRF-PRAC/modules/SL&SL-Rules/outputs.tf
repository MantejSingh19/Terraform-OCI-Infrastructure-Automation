output "security_list_ids" {

  description = "Map of Security List IDs"

  value = {

    for security_list_name, security_list_resource in oci_core_security_list.this :

    security_list_name => security_list_resource.id
  }
}