resource "oci_core_security_list" "this" {

  for_each = var.security_lists

  compartment_id = var.compartment_id

  vcn_id = var.vcn_ids[each.value.vcn_name]

  display_name = each.key

  dynamic "ingress_security_rules" {

    for_each = each.value.ingress_rules

    content {

      protocol = ingress_security_rules.value.protocol

      source = ingress_security_rules.value.source

      source_type = ingress_security_rules.value.source_type

      description = ingress_security_rules.value.description

      stateless = ingress_security_rules.value.stateless

      dynamic "tcp_options" {

        for_each = ingress_security_rules.value.tcp_options != null ? [1] : []

        content {

          min = ingress_security_rules.value.tcp_options.min

          max = ingress_security_rules.value.tcp_options.max
        }
      }

      dynamic "udp_options" {

        for_each = ingress_security_rules.value.udp_options != null ? [1] : []

        content {

          min = ingress_security_rules.value.udp_options.min

          max = ingress_security_rules.value.udp_options.max
        }
      }
    }
  }

  dynamic "egress_security_rules" {

    for_each = each.value.egress_rules

    content {

      protocol = egress_security_rules.value.protocol

      destination = egress_security_rules.value.destination

      destination_type = egress_security_rules.value.destination_type

      description = egress_security_rules.value.description

      stateless = egress_security_rules.value.stateless

      dynamic "tcp_options" {

        for_each = egress_security_rules.value.tcp_options != null ? [1] : []

        content {

          min = egress_security_rules.value.tcp_options.min

          max = egress_security_rules.value.tcp_options.max
        }
      }

      dynamic "udp_options" {

        for_each = egress_security_rules.value.udp_options != null ? [1] : []

        content {

          min = egress_security_rules.value.udp_options.min

          max = egress_security_rules.value.udp_options.max
        }
      }
    }
  }
}