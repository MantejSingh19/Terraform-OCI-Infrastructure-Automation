output "vcn_ids" {

  description = "Map of VCN IDs"

  value = {

    for vcn_name, vcn_resource in oci_core_vcn.this :

    vcn_name => vcn_resource.id
  }
}

output "vcn_cidrs" {

  description = "Map of VCN CIDRs"

  value = {

    for vcn_name, vcn_resource in oci_core_vcn.this :

    vcn_name => vcn_resource.cidr_blocks[0]
  }
}

