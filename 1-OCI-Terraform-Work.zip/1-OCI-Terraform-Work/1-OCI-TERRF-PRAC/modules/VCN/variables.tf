variable "compartment_id" {

  description = "OCI Compartment OCID"

  type = string
}

variable "vcns" {

  description = "Map of VCN configurations"

  type = map(object({

    cidr_block = string

    dns_label  = string

  }))
}