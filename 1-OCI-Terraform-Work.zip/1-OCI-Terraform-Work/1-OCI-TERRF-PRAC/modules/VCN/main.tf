resource "oci_core_vcn" "this" {

  for_each = var.vcns

  compartment_id = var.compartment_id

  display_name = each.key

  cidr_blocks = [each.value.cidr_block]

  dns_label = each.value.dns_label
}