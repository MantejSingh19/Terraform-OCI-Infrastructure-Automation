output "lpg_ids" {

  description = "Map of LPG IDs"

  value = {

    for lpg_name, lpg_resource in
    oci_core_local_peering_gateway.this :

    lpg_name => lpg_resource.id
  }
}