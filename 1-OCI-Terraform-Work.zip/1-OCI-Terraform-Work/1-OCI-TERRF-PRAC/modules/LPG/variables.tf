variable "compartment_id" {

  description = "OCI Compartment OCID"

  type = string
}

variable "vcn_ids" {

  description = "Map of VCN IDs"

  type = map(string)
}

variable "lpgs" {

  description = "Map of LPG configurations"

  type = map(object({

    vcn_name = string
  }))
}