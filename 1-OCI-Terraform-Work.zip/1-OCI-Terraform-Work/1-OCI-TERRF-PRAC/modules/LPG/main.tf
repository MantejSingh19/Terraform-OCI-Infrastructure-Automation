resource "oci_core_local_peering_gateway" "this" {

  for_each = var.lpgs

  compartment_id = var.compartment_id

  vcn_id = var.vcn_ids[each.value.vcn_name]

  display_name = each.key
}