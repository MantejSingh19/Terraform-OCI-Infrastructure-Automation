variable "compartment_id" {

  description = "OCI Compartment OCID"

  type = string
}

variable "vcn_ids" {

  description = "Map of VCN IDs"

  type = map(string)
}

variable "route_tables" {

  description = "Map of Route Table configurations"

  type = map(object({

    vcn_name = string

    route_rules = list(object({

      destination = string

      destination_type = string

      network_entity_id = string

      description = optional(string)
    }))
  }))
}