output "route_table_ids" {

  description = "Map of Route Table IDs"

  value = {

    for route_table_name, route_table_resource in oci_core_route_table.this :

    route_table_name => route_table_resource.id
  }
}