resource "oci_core_route_table" "this" {

  for_each = var.route_tables

  compartment_id = var.compartment_id

  vcn_id = var.vcn_ids[each.value.vcn_name]

  display_name = each.key

  dynamic "route_rules" {

    for_each = each.value.route_rules

    content {

      destination = route_rules.value.destination

      destination_type = route_rules.value.destination_type

      network_entity_id = route_rules.value.network_entity_id

      description = lookup(route_rules.value, "description", null)
    }
  }
}