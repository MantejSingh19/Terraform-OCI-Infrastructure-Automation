variable "compartment_id" {

  description = "OCI Compartment OCID"

  type = string
}

variable "subnet_ids" {

  description = "Map of Subnet IDs"

  type = map(string)
}

variable "instances" {

  description = "Map of Compute Instance configurations"

  type = map(object({

    subnet_name = string

    availability_domain = string

    shape = string

    ocpus = number

    memory_in_gbs = number

    assign_public_ip = bool

    private_ip = optional(string)

    ssh_public_key_path = string

    image_ocid = string

    boot_volume_size_in_gbs = optional(number, 50)
  }))
}