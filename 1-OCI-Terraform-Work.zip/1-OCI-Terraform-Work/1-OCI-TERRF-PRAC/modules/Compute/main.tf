resource "oci_core_instance" "this" {

  for_each = var.instances

  compartment_id = var.compartment_id

  availability_domain = each.value.availability_domain

  display_name = each.key

  shape = each.value.shape

  shape_config {

    ocpus         = each.value.ocpus

    memory_in_gbs = each.value.memory_in_gbs
  }

  create_vnic_details {

    subnet_id = var.subnet_ids[each.value.subnet_name]

    assign_public_ip = each.value.assign_public_ip

    private_ip = lookup(each.value, "private_ip", null)
  }

  source_details {

    source_type = "image"

    source_id = each.value.image_ocid

    boot_volume_size_in_gbs = each.value.boot_volume_size_in_gbs
  }

  metadata = {

    ssh_authorized_keys = file(each.value.ssh_public_key_path)
  }
}