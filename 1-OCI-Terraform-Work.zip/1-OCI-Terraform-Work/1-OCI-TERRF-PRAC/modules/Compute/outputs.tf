output "instance_ids" {

  description = "Map of Instance IDs"

  value = {

    for instance_name, instance_resource in oci_core_instance.this :

    instance_name => instance_resource.id
  }
}