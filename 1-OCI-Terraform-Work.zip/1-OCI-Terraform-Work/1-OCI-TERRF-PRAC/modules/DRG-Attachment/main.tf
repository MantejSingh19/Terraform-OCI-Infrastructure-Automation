resource "oci_core_drg_attachment" "this" {

  for_each = var.drg_attachments

  drg_id = var.drg_ids[each.value.drg_name]

  network_details {

    id = var.vcn_ids[each.value.vcn_name]

    type = "VCN"
  }

  display_name = each.key
}