variable "drg_ids" {

  description = "Map of DRG IDs"

  type = map(string)
}

variable "vcn_ids" {

  description = "Map of VCN IDs"

  type = map(string)
}

variable "drg_attachments" {

  description = "Map of DRG attachment configurations"

  type = map(object({

    drg_name = string

    vcn_name = string
  }))
}