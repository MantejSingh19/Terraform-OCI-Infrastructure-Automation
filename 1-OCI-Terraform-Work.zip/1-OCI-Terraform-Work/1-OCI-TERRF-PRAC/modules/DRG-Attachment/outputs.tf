output "drg_attachment_ids" {

  description = "Map of DRG Attachment IDs"

  value = {

    for attachment_name, attachment_resource in oci_core_drg_attachment.this :

    attachment_name => attachment_resource.id
  }
}