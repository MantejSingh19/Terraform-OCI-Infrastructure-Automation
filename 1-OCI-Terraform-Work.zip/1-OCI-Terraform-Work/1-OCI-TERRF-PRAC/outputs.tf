output "vcn_ids" {

  value = module.vcn.vcn_ids
}