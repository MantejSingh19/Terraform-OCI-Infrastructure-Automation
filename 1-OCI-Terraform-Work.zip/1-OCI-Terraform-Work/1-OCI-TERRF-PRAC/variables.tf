variable "region" {

  description = "OCI Region"

  type = string
}

variable "compartment_id" {

  description = "OCI Compartment OCID"

  type = string
}

variable "vcns" {

  description = "Map of VCN configurations"

  type = map(object({

    cidr_block = string

    dns_label  = string

  }))
}
variable "availability_domain" {

  description = "OCI Availability Domain"

  type = string
}
variable "subnets" {

  description = "Map of subnet configurations"

  type = map(object({

    vcn_name = string

    cidr_block = string

    dns_label = string

    prohibit_public_ip_on_vnic = bool

    security_list_ids = optional(list(string), [])

    route_table_id = optional(string)

  }))
}
variable "security_lists" {

  description = "Map of Security List configurations"

  type = map(object({

    vcn_name = string

    ingress_rules = list(any)

    egress_rules = list(any)

  }))
}
variable "route_tables" {

  description = "Map of Route Table configurations"

  type = map(object({

    vcn_name = string

    route_rules = list(object({

      destination = string

      destination_type = string

      network_entity_id = string

      description = optional(string)
    }))
  }))
}
variable "instances" {

  description = "Map of Compute Instance configurations"

  type = map(object({

    subnet_name = string

    availability_domain = string

    shape = string

    ocpus = number

    memory_in_gbs = number

    assign_public_ip = bool

    private_ip = optional(string)

    ssh_public_key_path = string

    image_ocid = string

    boot_volume_size_in_gbs = optional(number, 50)
  }))
}
variable "drgs" {

  type = map(object({

    display_name = string
  }))
}

variable "drg_attachments" {

  type = map(object({

    drg_name = string

    vcn_name = string
  }))
}
variable "lpgs" {

  description = "Map of LPG configurations"

  type = map(object({

    vcn_name = string
  }))
}
